plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.blogapp"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.blogapp"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)

    //platform api 이외에 라이브러리 사용 등록, 다운로드..
    //Sync Now 순간 다운로드..
    //implementation("group_id:artifact_id:version")
    //하나의 프로젝트 내에 여러 모듈이 있고, 모듈별로 라이브러리 등록하는데, 동일 라이브러리를 중복 등록하는 경우가 있다..
    //라이브러리 버전 변경시에 모든 모듈의 build.gradle.kts 를 수정하는 것이 불편하다고 봐서...
    //라이브러리 등록을 libs.versions.toml 에 통합등록하고.. 개별 모듈에서는 링크로 연결해서 사용..
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
}





