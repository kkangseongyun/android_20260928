package com.example.blogapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.blogapp.ui.blog.BlogViewModel
import com.example.blogapp.ui.blog.detail.BlogDetailScreen
import com.example.blogapp.ui.blog.edit.BlogEditScreen
import com.example.blogapp.ui.blog.list.BlogListScreen
import com.example.blogapp.ui.home.HomeScreen
import com.example.blogapp.ui.myinfo.MyInfoScreen
import com.example.blogapp.ui.myinfo.MyInfoViewModel


//각 화면을 이름으로 등록할 생각이다.
//이름 문자열이다. 화면 전환 요청하는 곳에서 문자열 오타 가능성등..
//타입 안정성을 위해서.. sealed 클래스를 이용하겠다.

//일종의 enum 사상. 내가 준비한대로만 사용하라.. 더 확장해서 만들지 마라..
//enum 보다.. 변수, 함수 추가가 편해서.. enum 이 필요한대 약간의 데이터와 로직을 유지해야 하는 경우에 주로 사용..
sealed class Screen(val route: String){
    //결국 화면의 이름을 "home" 으로 하는데.. 이것을 Home 타입으로 지정하게.. 오타가 허용되지 않는다.
    object Home: Screen("home")
    object MyInfo: Screen("my_info")
    object BlogList: Screen("blog_list")
    object BlogEdit: Screen("blog_edit?postId={postId}") {
        //아규먼트 포함..
        //개발자 임의 함수이다. 화면전환 요청 문자열 쉽게 만들라고..
        fun createRoute(postId: Long? = null) =
            if (postId != null) "blog_edit?postId=$postId" else "blog_edit"
    }
    object BlogDetail: Screen("blog_detail/{postId}"){
        fun createRoute(postId: Long) = "blog_detail/$postId"
    }
}

@Composable
fun BlogNavHost(navController: NavHostController = rememberNavController()) {

    //개별 composable 에서 직접 viewmodel 획득 이용도 가능하지만..
    //navigation 에서 획득해서 전달해 주겠다..
    //viewmodel 의 이용 범위를 한정짓기 위해서..
    val myInfoViewModel: MyInfoViewModel = viewModel()
    val blogViewModel: BlogViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ){
        //화면 등록..
        composable(Screen.Home.route){
            HomeScreen(
                viewModel = myInfoViewModel,
                onNavigateToMyInfo = { navController.navigate(Screen.MyInfo.route)},
                onNavigateToBlogList = { navController.navigate(Screen.BlogList.route)}
            )
        }
        composable(Screen.MyInfo.route){
            MyInfoScreen(
                viewModel = myInfoViewModel,
                onBack = { navController.popBackStack() }
            )
        }
        //NavHostController 를 각 컴포저블에 넘겨서 컴포저블에서 직접 navigate() 함수 호출로 화면 전환을 할 수도 있지만..
        composable(Screen.BlogList.route){
            BlogListScreen(
                viewModel = blogViewModel,
                onNavigateToBlogDetail = { postId ->
                    navController.navigate(Screen.BlogDetail.createRoute(postId))
                },
                onNavigateToBlogEdit = {
                    navController.navigate(Screen.BlogEdit.createRoute())
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }
        composable(
            route = Screen.BlogEdit.route,
            arguments = listOf(//전달 받아야 하는 데이터 명시..
                navArgument("postId"){
                    type = NavType.LongType
                    defaultValue = -1L//optional
                }
            )
        ){ backStackEntry -> //BackStackEntry, 실제 화면 전환시에 NavHost에서 백스택에 유지하는 객체.. 이 객체에 화면 전환과 관련된
            //모든 정보, 어느 이름의 화면이고, 그때 넘기는 데이터가 무엇이고 등등이 유지된다.
            //전달된 데이터 획득..
            val postId = backStackEntry.arguments?.getLong("postId") ?: -1L
            BlogEditScreen(
                viewModel = blogViewModel,
                postId = if(postId == -1L) null else postId,
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() }
            )
        }
        composable(
            route = Screen.BlogDetail.route,
            arguments = listOf(
                navArgument("postId"){
                    type = NavType.LongType
                }
            )
        ) { backStackEntry ->
            val postId = backStackEntry.arguments?.getLong("postId") ?: return@composable
            BlogDetailScreen(
                viewModel = blogViewModel,
                postId = postId,
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(Screen.BlogEdit.createRoute(postId))},
                onDelete = { navController.popBackStack() }
            )
        }
    }
}

















