package com.example.blogapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.blogapp.ui.blog.detail.BlogDetailScreen
import com.example.blogapp.ui.blog.edit.BlogEditScreen
import com.example.blogapp.ui.blog.list.BlogListScreen
import com.example.blogapp.ui.home.HomeScreen
import com.example.blogapp.ui.myinfo.MyInfoScreen


//각 화면을 이름으로 등록할 생각이다.
//이름 문자열이다. 화면 전환 요청하는 곳에서 문자열 오타 가능성등..
//타입 안정성을 위해서.. sealed 클래스를 이용하겠다.

//일종의 enum 사상. 내가 준비한대로만 사용하라.. 더 확장해서 만들지 마라..
//enum 보다.. 변수, 함수 추가가 편해서.. enum 이 필요한대 약간의 데이터와 로직을 유지해야 하는 경우에 주로 사용..
sealed class Screen(val route: String){
    //결국 화면의 이름을 "home" 으로 하는데.. 이것을 Home 타입으로 지정하게.. 오타가 허용되지 않는다.
    object Home: Screen("home")
    object MyInfo: Screen("my_info")
    object BlogList: Screen("blog_list")
    object BlogEdit: Screen("blog_edit?postId={postId}") {
        //아규먼트 포함..
        fun createRoute(postId: Long? = null) =
            if (postId != null) "blog_edit?postId=$postId" else "blog_edit"
    }
}

@Composable
fun BlogNavHost() {
    //상태 선언..
    var currentScreen by rememberSaveable { mutableStateOf("home") }

    when(currentScreen){
        "home" -> HomeScreen(
            onNavigateToBlogList = { currentScreen = "blogList" },
            onNavigateToMyInfo = { currentScreen = "myInfo" },
        )
        "myInfo" -> MyInfoScreen(
            onBack = { currentScreen = "home" }
        )
        "blogList" -> BlogListScreen(
            onBack = { currentScreen = "home" },
            onNavigateToBlogDetail = { currentScreen = "blogDetail" },
            onNavigateToBlogEdit = { currentScreen = "blogEdit" },
        )
        "blogDetail" -> BlogDetailScreen(
            onBack = { currentScreen = "blogList" }
        )
        "blogEdit" -> BlogEditScreen(
            onBack = { currentScreen = "blogList" }
        )
    }
}