package com.example.blogapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.blogapp.ui.blog.detail.BlogDetailScreen
import com.example.blogapp.ui.blog.edit.BlogEditScreen
import com.example.blogapp.ui.blog.list.BlogListScreen
import com.example.blogapp.ui.home.HomeScreen
import com.example.blogapp.ui.myinfo.MyInfoScreen

@Composable
fun BlogNavHost() {
    //상태 선언..
    var currentScreen by rememberSaveable { mutableStateOf("home") }

    when(currentScreen){
        "home" -> HomeScreen(
            onNavigateToBlogList = { currentScreen = "blogList" },
            onNavigateToMyInfo = { currentScreen = "myInfo" },
        )
        "myInfo" -> MyInfoScreen(
            onBack = { currentScreen = "home" }
        )
        "blogList" -> BlogListScreen(
            onBack = { currentScreen = "home" },
            onNavigateToBlogDetail = { currentScreen = "blogDetail" },
            onNavigateToBlogEdit = { currentScreen = "blogEdit" },
        )
        "blogDetail" -> BlogDetailScreen(
            onBack = { currentScreen = "blogList" }
        )
        "blogEdit" -> BlogEditScreen(
            onBack = { currentScreen = "blogList" }
        )
    }
}