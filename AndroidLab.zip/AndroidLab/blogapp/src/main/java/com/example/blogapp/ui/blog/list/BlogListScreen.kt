package com.example.blogapp.ui.blog.list

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.blogapp.domain.model.BlogPost


//테스트를 위한 가상의 데이터..
val posts: List<BlogPost> = listOf(
    BlogPost(id = 1, title = "title1", content = "content1", author = "author1", imageUri = null),
    BlogPost(id = 2, title = "title2", content = "content1", author = "author1", imageUri = null),
    BlogPost(id = 3, title = "title3", content = "content1", author = "author1", imageUri = null),
    BlogPost(id = 4, title = "title4", content = "content1", author = "author1", imageUri = null),
    BlogPost(id = 5, title = "title5", content = "content1", author = "author1", imageUri = null),
)

@Composable
fun BlogListScreen(
    onBack: () -> Unit,
    onNavigateToBlogDetail: (Long) -> Unit,
    onNavigateToBlogEdit: () -> Unit,
) {

    Scaffold(

    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("BlogListScreen")
            Button(
                onClick = onBack
            ) {
                Text("Go Back")
            }
//            Button(
//                onClick = onNavigateToBlogDetail
//            ) {
//                Text("Go Detail")
//            }
            Button(
                onClick = onNavigateToBlogEdit
            ) {
                Text("Go Edit")
            }

            
        }
    }


}