package com.example.blogapp.ui.blog

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.blogapp.domain.model.BlogPost

class BlogViewModel: ViewModel() {
    //post 데이터를 이곳에서 유지한다..
    //compose 다.. 이 데이터에 의해 composeable 이 갱신되어야 한다.. 상태
    //composable 의 상태를 viewmodel에 선언..
    //이 상태를 이용하는 composable 이 상태 변경시에 갱신된다..
    //개별 composable 에서 유지되는 상태가 아니다.. remember 필요 없다..
    var posts by mutableStateOf(mutableListOf<BlogPost>())
        private set//이 값 변경 가능하다(var), 단 외부에서는 안된다. 외부에서는 이용만 하라..

    //여러 포스트 중에서 현재 선택된.. edit, detail
    var selectedPost: BlogPost? by mutableStateOf(null)

    //개발자 임의 함수.. composable 에서 b/l 이 필요할때 호출..
    fun loadPost(id: Long){
        selectedPost = posts.find { it.id == id }
    }

    fun savePost(id: Long, title: String, content: String, imageUri: String?){
        //매개변수의 id 에 해당되는 데이터의 첫번째 index
        val index = posts.indexOfFirst { it.id == id }
        if(index != -1){//이전에 저장된 것이 있다.. 수정..
            val existing = posts[index]
            posts[index] = existing.copy(
                title = title,
                content =  content,
                imageUri = imageUri
            )
        }else {
            //신규 저장..
            posts.add(
                BlogPost(
                    id = posts.size.toLong() + 1,
                    title = title,
                    content = content,
                    author = "author",
                    imageUri = imageUri
                )
            )
        }
    }
    fun deletePost(id: Long){
        posts.removeAll { it.id == id }
    }
}