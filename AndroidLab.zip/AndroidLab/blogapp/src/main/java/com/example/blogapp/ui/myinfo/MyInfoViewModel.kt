package com.example.blogapp.ui.myinfo

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

//AndroidViewModel 상속받으면 자동으로 Application 객체 전달..
class MyInfoViewModel(application: Application): AndroidViewModel(application) {
    var email by mutableStateOf("")
        private set

    fun saveEmail(email: String){
        this.email = email
    }
}