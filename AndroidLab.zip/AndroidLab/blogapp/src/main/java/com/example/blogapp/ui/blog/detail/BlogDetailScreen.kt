package com.example.blogapp.ui.blog.detail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

@Composable
fun BlogDetailScreen(
    onBack: () -> Unit,
) {
    //세로방향으로.. 나열..
    Column(
        modifier = Modifier.fillMaxSize(),//ui 정보 설정.. 화면 전체 차지하라..
        horizontalAlignment = Alignment.CenterHorizontally,//가로방향 중앙 정렬..
        verticalArrangement = Arrangement.Center,//세로방향 중앙 정렬..
    ) {
        Text("BlogDetailScreen")
        Button(
            onClick = onBack
        ) {
            Text("Go Back")
        }
    }
}