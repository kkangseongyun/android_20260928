package com.example.blogapp.ui.blog.detail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.blogapp.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREAN)
    return sdf.format(Date(timestamp))
}

@Composable
fun BlogDetailScreen(
    onBack: () -> Unit,
) {
    ConstraintLayout(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 60.dp)
            //재구성시에. 스크롤 정보 유지되어야한다.
            .verticalScroll(rememberScrollState())
    ) {
        //식별자 변수 선언..
        val (image, title, authorRow, updateText, divider, content) = createRefs()

        //이미지를 리소스에서 로딩.. Coil 을 이용해서..
        //가장 기본 컴포저블은 AsyncImage
        //SubcomposeAsyncImage - 이미지 로딩, 에러 이미지등 설정 가능..
        SubcomposeAsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(R.drawable.main_swiss)
                .crossfade(true)//이미지 로딩 완료시 이미지 출력 애니메이션 효과 적용하라..
                .build(),
            contentDescription = "타이틀",
            //화면 출력 사이즈와 이미지 사이즈가 맞지 않은 경우 어떻게 할것인가?
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .constrainAs(image){
                    top.linkTo(parent.top)
                },
            loading = {//이미지 로딩 전에 출력..
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        )

        Text(
            text = "타이틀",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, top = 20.dp, end = 20.dp)
                .constrainAs(title){
                    top.linkTo(image.bottom)
                }
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .constrainAs(authorRow){
                    top.linkTo(title.bottom)
                }
        ) {
            Text(
                text = "작성자 : Unknown",
                style= MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = " . ",
                style= MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = formatDate(System.currentTimeMillis()),
                style= MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            text = "수정됨 : ",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .constrainAs(updateText){
                    top.linkTo(authorRow.bottom)
                }
        )

        HorizontalDivider(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .constrainAs(divider){
                    top.linkTo(updateText.bottom)
                }
        )

        Text(
            text = "(내용 없음) ",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, bottom = 20.dp)
                .constrainAs(content){
                    top.linkTo(divider.bottom)
                }
        )
    }
}