package com.example.blogapp.ui.myinfo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch

@Composable
fun MyInfoScreen(
    onBack: () -> Unit,
) {

    //SnackbarHostState() 에서 상태를 유지한다.. 우리는 그 상태값을 변경만 하면 된다..
    val snackbarHostState = remember { SnackbarHostState() }

    //코루틴을 만들어서 구동시키려면 꼭 scope 가 먼저 선언되어야 하고.. 그 scope 소속으로 코루틴을 만들어 구동해야 한다..
    //CoroutineScope 는 여러 코루틴을 묶어서 한꺼번에 제어하는 역할..
    //Compose 에서 Scope 를 쉽게 사용하기 위해서.. rememberCoroutineScope()
    //자동으로.. 이 composable 제거시에..scope 내의 coroutine 종료..
    //SnackBar 띄우는 함수는 꼭..coroutine 내에서 호출하게 되어 있어서..
    //suspend 로 선언된 함수는 꼭 coroutine 이 준비되어야 한다..
    val scope = rememberCoroutineScope()

    //화면의 기본 구조 제공..
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("MyInfoScreen")
            Button(
                onClick = onBack
            ) {
                Text("Go Back")
            }
            Button(
                onClick = {
                    //launch : coroutine builder
                    scope.launch {
                        snackbarHostState.showSnackbar("저장되었습니다.")
                    }

                }
            ) {
                Text("SnackBar")
            }
        }
    }

}